//
//  ViewController.swift
//  PersonalJournal
//
//  Created by Belizaire, Reuel James on 4/11/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

